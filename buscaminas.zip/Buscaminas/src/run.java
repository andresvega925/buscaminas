
public class run {

	public static void main(String[] args) {
		
		logica m = new logica();
		m.matriz();

	}

}
