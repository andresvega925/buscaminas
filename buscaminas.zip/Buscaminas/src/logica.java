import java.util.Random;
import java.util.Scanner;

public class logica {
	
	
	private int filas;
	private int minas;
	private int columnas;
	private String tableroMostrar[][];
	private String tableroOculto[][];
	private Scanner sc;
	private boolean parar = false;
	private int filSel;
	private int colSel;
	private String accion;
	private int auxmarca = 0;
	
	public void matriz() {
		
			sc = new Scanner(System.in);
			
			boolean filco = true;
			while(filco){
			System.out.println("Ingrese el número de filas");
			filas= sc.nextInt();
			
			System.out.println("Ingrese el número de columnas");
			columnas= sc.nextInt();			
			
			if(filas > 0 && columnas > 0){				
				
				boolean min = true;
				System.out.println("Ingrese el número de minas");


				while(min) {
					minas= sc.nextInt();					
					if (minas > 0 && minas < columnas * filas) {
						tableroMostrar = new String[filas][columnas];		
						tableroOculto = new String[filas][columnas];		
						for(int i=0; i<filas; i++){
							int j = 0;
							for (j = 0; j <columnas; j++) {							
								tableroMostrar[i][j] = ".";		
								tableroOculto[i][j] = ".";		
								System.out.print(tableroMostrar[i][j] + " ");																				
							}
							System.out.println();						
						}										
						//Poner las minas en el tablero
						ponerMinasAleatoriamente();
						datosTurno();
						min = false;				
					}else{
						System.out.println("¡El número de minas debe ser menor que (Filas x Columnas), es decir: < " + filas * columnas +"! y mayor que 0");
						System.out.println("\nIngrese el número de minas");
					}					
				}			
					filco = false;	//para finalizar la opción de entrada de datos filas  y columnas
		}else {			
			System.out.println("Los valores de filas y columnas deben ser superiores a 0 ");
		}		
	}			
}
	
	
	/*************************************************************************************************************
	*                                                     datosTurno                                                       *
	**************************************************************************************************************/
	
	public void datosTurno() {
		
		while(parar == false){
			

			System.out.println("Ingrese la fila que desea seleccionar");
			filSel = sc.nextInt();			

			
					
			System.out.println("Ingrese la columna que desea seleccionar");
			colSel = sc.nextInt();

			
			System.out.println("Seleccione una acción\n[U] = Descubrir celda \n[M] = Marcar como que contiene una mina");
			accion = sc.next();	
			
			
			
			if(filSel >= 0 && filSel < filas && colSel >= 0 && colSel < columnas  ) {
					//turno del jugador
					turno(filSel, colSel, accion);		
				}else {
					System.out.println("Hay al menos un valor invalido, vuelva a ingresar los datos");
				
				}
	}
		
}

	/*************************************************************************************************************
	*                                                  Turno                                                          *
	**************************************************************************************************************/
	public boolean turno(int row, int col, String acc ){
							
		if(row >= 0 && row <= filas && col >= 0 && col <= columnas && acc.equals("U") || acc.equals("u") || acc.equals("M") || acc.equals("m")){
			parar = true;
			
			//Seleccionar el método que ejecuta la acción seleccionada por el jugador 
			if(acc.equals("u") || acc.equals("U")){
				
				destapar(row,col);
				
			}else {
				
				marcar(row,col);
			}
			
			
		}else {
			System.out.println("El valor de la fila, de la columna  o de la acción es invalido, por favor ingrese nuevamente los valores\n");
			parar = false;					
		}
		return parar;
				
	}
	

	
	
	public void destapar(int rw, int cl){

		circundantes(rw, cl);
		//lógica con los valores ingresados
		validarPosicion(rw, cl);

		
	}
	
	/*************************************************************************************************************
	*                                                  marcar                                                          *
	**************************************************************************************************************/
	public void marcar(int rw, int cl){			
		
		if(tableroMostrar[rw][cl] == "P" || tableroMostrar[rw][cl] == "-") {
			System.out.println("¡Esta posición ya ha sido utilizada, ingrese otra posición");
			parar = false;//para que se siga ejecutando el método datosTurno();			
			datosTurno();//volver a pedir datos para el nuevo turno
		}else {
			tableroMostrar[rw][cl] = "P";
			tableroActual();
			parar = false;
			auxmarca++;
			if(auxmarca > minas) {
						System.out.println("!hay más banderas que minas!");
						mostrarTablero();
						parar = true;
			}else if(auxmarca <= minas){
		
				validarBanderas();
			
			}else {
				datosTurno();
			}
		}
	}

	/*************************************************************************************************************
	*                                      validar banderas                                                       *
	**************************************************************************************************************/
	
	public void validarBanderas(){
		
			int aux = 0;
			for (int i = 0; i < filas; i++) {
				for (int j = 0; j < columnas; j++) {
					
					if(tableroMostrar[i][j] == "P" && tableroOculto[i][j]=="*"){
						
						aux++;
						if(aux == minas){
							parar = true;
							System.out.println("¡Felicitaciones, has ganado! ¡acertaste todas las banderas! ");
						}
						
					}
				}
			}
		
	}

	
	
	/*************************************************************************************************************
	*                                           validar posición                                                         *
	**************************************************************************************************************/
	public void validarPosicion(int fil, int col){				
		
		if(tableroOculto[fil ][col ] == "."){			
			modificarTableroBarra(fil, col);
			parar = false;//para que se siga ejecutando el método datosTurno();			
			datosTurno();//volver a pedir datos para el nuevo turno
			
			
		}else if(tableroOculto[fil][col] == "*"){
		
			mostrarTablero();
			
		}else if(tableroOculto[fil][col] == "-") {
			System.out.println("¡Esta posición ya ha sido utilizada, ingrese otra posición");
			parar = false;//para que se siga ejecutando el método datosTurno();			
			datosTurno();//volver a pedir datos para el nuevo turno
			
		}
		
		else {			
//			System.out.println("barra");
		}		
				
	}
	
	/*************************************************************************************************************
	*                                       mod Tablero                                                                     *
	**************************************************************************************************************/
	
	public void modificarTableroBarra(int f, int c){
		

			circundantes(f, c);
			tableroOculto[f][c] = "-";
			tableroActual();
		
	}

	
	
	/*************************************************************************************************************
	*                                            minas pos                                                       *
	**************************************************************************************************************/
	public void ponerMinasAleatoriamente() {
		
			int aux = 0;	
			while(aux < minas){
			//Generar valores aleatorios para poner las minas		
			int co = (int)(Math.random()*columnas);
			int fi = (int)(Math.random()*filas);

			if(tableroOculto[fi][co] != "*") {				
				tableroOculto[fi][co] = "*";
				aux++;
			}	

		}
		
	}		
	
	/*************************************************************************************************************
	*                                        Lógica Circundantes                                                 *
	**************************************************************************************************************/
	
	public void circundantes(int fil, int col){
		

		//esquina superior izq
		if(fil == 0 && col == 0){

			int aux = 0;
			if(tableroOculto[fil][col +1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col + 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";
			}
			
		}else if(fil == 0 && col > 0 && col < columnas - 1){ // para los valores de la fila 0 con col > 0 y col < (columnas-1)
			
			int aux = 0;
			
			if(tableroOculto[fil][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil][col + 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col] == "*" ) {
				aux++;
			}
			if(tableroOculto[fil + 1][col + 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";
			}

			
		}
		
		
		//esquina inferior izq
		if(fil == filas-1 && col == 0){
			
			int aux = 0;
			if(tableroOculto[fil][col +1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil -1][col] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil - 1][col + 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";

			}
			
		}else if(fil == filas - 1 && col > 0 && col < columnas - 1){ // para los valores de la fila 0 con col > 0 y col < (columnas-1)
			
			int aux = 0;
			
			if(tableroOculto[fil][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil][col + 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil - 1][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil - 1][col] == "*" ) {
				aux++;
			}
			if(tableroOculto[fil - 1][col + 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";
			}

		}		
		
		
		//esquina superior der
		if(fil == 0 && col == columnas -1){

			int aux = 0;
			if(tableroOculto[fil][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col ] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col - 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);
			}else {
				tableroMostrar[fil][col] = "-";

			}
			
		}else if(fil == 0 && col > 0 && col == columnas - 2){ // para los valores de la fila 0 con col > 0 y col = (columnas-1)
			
			int aux = 0;
			
			if(tableroOculto[fil][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil][col + 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col] == "*" ) {
				aux++;
			}
			if(tableroOculto[fil + 1][col + 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";
			}
		}

		
		
		//esquina inferior der
		if(fil == filas-1 && col == columnas - 1){
			
			int aux = 0;
			if(tableroOculto[fil -1][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil -1][col] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil ][col] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";
			}
		}else if(fil == filas - 1 && col > 0 && col == columnas - 2){ // para los valores de la fila 0 con col > 0 y col = (columnas-1)
			
			int aux = 0;
			
			if(tableroOculto[fil][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil][col + 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil - 1][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil - 1][col] == "*" ) {
				aux++;
			}
			if(tableroOculto[fil - 1][col + 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";
			}
		}

		
		/**Lógica para los bordes**/
		
		//borde izquierdo
		if(fil > 0 && fil < filas -1 && col == 0){
			int aux = 0;
			
			if(tableroOculto[fil - 1][col] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil][col + 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil - 1][col + 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col + 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";
			}
			
		}
		
		
		
		
		//borde derecho
		if(fil > 0  && fil < filas - 1 && col == columnas - 1 ){
			int aux = 0;
			
			if(tableroOculto[fil - 1][col] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil - 1][col - 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col - 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";
			}
			
		}
		
		
		
		/**Centro**/
		
		if(fil > 0 && fil < filas -1 && col > 0 && col < columnas - 1){
			
			int aux = 0;
			
			if(tableroOculto[fil - 1][col ] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil - 1][col - 1 ] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil][col -1 ] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col - 1 ] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil + 1][col + 1 ] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil][col + 1] == "*" ) {
				aux++;
			}
			
			if(tableroOculto[fil - 1][col + 1] == "*" ) {
				aux++;
			}
			
			if(aux > 0) {
				tableroMostrar[fil][col] = String.valueOf(aux);

			}else {
				tableroMostrar[fil][col] = "-";
			}
			
			
		}
		
		
	}
	
	

		
	
	
	/*************************************************************************************************************
	*                                      visualizar                                                                      *
	**************************************************************************************************************/
	
	public void tableroActual() {
		
		System.out.println("actal");
		for (int i = 0; i < filas; i++) {
				for (int j = 0; j < columnas; j++) {
				System.out.print(tableroMostrar[i][j] + " ");					
			}
			System.out.println();
		}
		System.out.println();
		
	}

	
	public void mostrarTablero() {
		
		System.out.println("\n\n\n¡Game Over!" );
		for (int i = 0; i < filas; i++) {
				for (int j = 0; j < columnas; j++) {
					if(tableroOculto[i][j] == "-") {
						System.out.print(tableroMostrar[i][j] + " ");							
						
					}else if(tableroMostrar[i][j] == "P"){
						System.out.print(tableroMostrar[i][j] + " ");							
					}
					else {
						System.out.print(tableroOculto[i][j] + " ");	
					}
									
		}
			System.out.println();
		}
	}
	

}
